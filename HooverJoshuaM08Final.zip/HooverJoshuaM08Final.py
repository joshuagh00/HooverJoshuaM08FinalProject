import tkinter as tk
from tkinter import messagebox

# Create the main application window
root = tk.Tk()
root.title("Video Rental Service")

# Function to center a window on the screen


def center_window(window, width, height):
    screen_width = window.winfo_screenwidth()
    screen_height = window.winfo_screenheight()
    x = (screen_width - width) // 2
    y = (screen_height - height) // 2
    window.geometry(f'{width}x{height}+{x}+{y}')

# Function to create the main application window
# Create the main application window


def create_main_window():
    main_window = tk.Toplevel(root)
    main_window.title("Main Application")
    center_window(main_window, 800, 600)

    # Create a label to provide information to the user
    flag = tk.Label(main_window, text="Welcome to the Video Rental Service")
    flag.pack()

    # Create buttons for different actions
    rent_button = tk.Button(main_window, text="Rent a Video", command=rent_video)
    rent_button.pack()

    return_button = tk.Button(main_window, text="Return a Video", command=return_video)
    return_button.pack()

    history_button = tk.Button(main_window, text="View Rental History", command=view_history)
    history_button.pack()
# Define the rent_video function


def rent_video():
    video_id = input("Enter the video ID to rent: ")
    if video_id:
        # Implement video rental logic here (e.g., update the database, track rentals, etc.)
        print(f"You rented video with ID {video_id}")
    else:
        print("Invalid input. Please enter a valid video ID.")

# Define the return_video function


def return_video():
    video_id = input("Enter the video ID to return: ")
    if video_id:
        # Implement video return logic here (e.g., update the database, track returns, etc.)
        print(f"You returned video with ID {video_id}")
    else:
        print("Invalid input. Please enter a valid video ID.")

# Define the view_history function


def view_history():
    # Implement viewing rental history functionality here (e.g., fetch rental history from a database)
    print("Rental History:")
    # Display rental history details


# Callback function for opening the main application window

def open_main_window():
    create_main_window()

# Button to open the main application window


main_button = tk.Button(root, text="Main Application", command=open_main_window)
main_button.pack()


# Button to exit the application
exit_button = tk.Button(root, text="Exit", command=root.quit)
exit_button.pack()

# Start the main loop
root.mainloop()
# Function to create the login window


# Function to create the login window
def create_login_window():
    login_window = tk.Toplevel(root)
    login_window.title("Login")
    center_window(login_window, 400, 200)

    # Create labels and entry fields for username and password
    username_label = tk.Label(login_window, text="Username:")
    username_label.pack()
    username_entry = tk.Entry(login_window)
    username_entry.pack()

    password_label = tk.Label(login_window, text="Password:")
    password_label.pack()
    password_entry = tk.Entry(login_window, show="*")  # Show password as asterisks
    password_entry.pack()

    # Create a function to perform user authentication
    def authenticate_user():
        username = username_entry.get()
        password = password_entry.get()
        # Implement user authentication logic here
        if username == "username" and password == "password":
            # Successful login
            messagebox.showinfo("Login", "Login Successful")
            login_window.destroy()
            create_main_window()  # Open the main application window
        else:
            # Failed login
            messagebox.showerror("Login Error", "Invalid username or password")

    # Create a login button
    login_button = tk.Button(login_window, text="Login", command=authenticate_user)
    login_button.pack()

# Callback function for opening the login window


def open_login_window():
    create_login_window()


# Button
signin_button = tk.Button(root, text="Login", command=open_login_window)
signin_button.pack()


def exit_application():
    root.destroy()


def some_function():
    # Implement the functionality for the button

    quit_button = tk.Button(main_window, text="Exit", command=exit_application)
    quit_button.pack()
# Create an Entry widget for user input


entry = tk.Entry(main_window)
entry.pack()


def validate_input():
    user_input = entry.get()
    if user_input:
        try:
            # Convert user input to the appropriate data type
            user_input = int(user_input)  # Change this to match your data type
            # Perform further validation
            if user_input >= 0:
                validate_input()
            else:
                messagebox.showerror("Error", "Please enter a valid value.")
        except ValueError:
            messagebox.showerror("Error", "Please enter a valid numeric value.")
    else:
        messagebox.showerror("Error", "Input cannot be empty.")
# Test Cases


validate_input()  # Empty input, should show an error
entry.insert(0, "abc")  # Invalid input, should show an error
validate_input()
entry.delete(0, "end")
entry.insert(0, "-5")  # Valid input, should proceed with functionality
validate_input()
